package day16;

public class Bike extends Vehicle{
void kickStart() {
	System.out.println("Bike is kick-started...");
}
}
