package day16;

public class Car extends Vehicle {
void drive() {
	System.out.println("Car Driving...");
}
}
