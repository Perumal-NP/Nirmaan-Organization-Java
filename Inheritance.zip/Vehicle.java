package day16;

public class Vehicle {
void startEngine(){
	System.out.println("Vehicle Engine Start....");
}
}
