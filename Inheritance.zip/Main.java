package day16;

public class Main {

	public static void main(String[] args) {
	System.out.println("single Inheritance");
	Car car=new Car();
	car.drive();
	car.startEngine();
	System.out.println("Multilevel Inheritance");
	ElectricCar ev=new ElectricCar();
	ev.drive();
	ev.chargeBattery();
	ev.startEngine();
	System.out.println("Hierarchical Inheritance");
	Bike bike=new Bike();
	bike.kickStart();
	bike.kickStart();

	}

}
