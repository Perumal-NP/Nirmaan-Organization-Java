package day16;

public class ElectricCar extends Car {
void chargeBattery() {
	System.out.println("Electric car is drive..");
}
}
