package libraryMangementSystem;

import java.util.ArrayList;
import java.util.Scanner;

public class UserInterface {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	ArrayList<Book> books=new ArrayList<Book>();
	BookServiceImpl service=new BookServiceImpl();
	
     boolean isWork=true;
     while(isWork) {
    	 System.out.println(" Enter the Number: \n 1.addBook \n 2.getBook \n 3.get the one Book \n 4.update book \n 5.delete book \n 6.exit ibrary ");
         int key=sc.nextInt();
    	 if(key==1) {
    		 books.add(service.addBook());
    	 }else if(key==2) {
    		 System.out.println(service.getBook(books));
    	 }else if(key==3) {
    		 System.out.println("Enter the BookId: ");
    		 int id=sc.nextInt();
    		 System.out.println(service.getBookId(id, books));
    	 }else if(key==4) {
    		 System.out.println("Enter the BookId: ");
    		 int id=sc.nextInt();
    		 System.out.println(service.updateBook(id, books));
    	 }else if(key==5) {
    		 System.out.println("Enter the BookId: ");
    		 int id=sc.nextInt();
    		 service.deleteBook(id, books);
    	 }else if(key==6) {
			 isWork=false;
    		 System.err.println("Thankyou for visit !!!");
    	 }else  {

    		 System.out.println("Inorrect key please enter crt key");
    	 }
     }
}
}
