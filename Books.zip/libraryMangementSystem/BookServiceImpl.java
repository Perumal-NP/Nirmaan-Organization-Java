package libraryMangementSystem;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class BookServiceImpl implements BookService{
  Scanner sc=new Scanner(System.in);
  
	@Override
	public Book addBook() {
		System.out.println("Enter the BookId: ");
		int id=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the BookName: ");
		String name=sc.nextLine();
		System.out.println("Enter the BookPrice: ");
		int price=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the Author Name: ");
		String author=sc.nextLine();
		
		return new Book(id, name, price, author);
	}

	@Override
	public ArrayList<Book> getBook(ArrayList<Book> book) {
		
		return book;
	}

	@Override
	public Book getBookId(int id, ArrayList<Book> book) {

		for(Book book1:book) {
			if(id==book1.getBookId()) {
				 return book1;
			}
		
	}
		return null;
		}

	@Override
	public String updateBook(int id,ArrayList<Book> book) {
	
		for(Book book1:book) {
		if(id==book1.getBookId()) {
			System.out.println("Enter the BookName: ");
			String name=sc.nextLine();
			book1.setBookName(name);
			System.out.println("Enter the BookPrice: ");
			int price=sc.nextInt();
			book1.setBookPrice(price);
			sc.nextLine();
			System.out.println("Enter the Author Name: ");
			String author=sc.nextLine();
			book1.setAuthor(author);
			return "Upadated Successfully !!!!!";
	}
	}
	
		return "No Record....";
	}

	@Override
	public void deleteBook(int id, ArrayList<Book> book) {
		Iterator<Book> iterator = book.iterator();
		boolean found = false;

		while (iterator.hasNext()) {
			Book b = iterator.next();
			if (b.getBookId() == id) {
				iterator.remove();
				found = true;
				System.out.println("Book deleted successfully.");
				break;
			}
		}

		if (!found) {
			System.out.println("Book not found.");
		}

	}
}