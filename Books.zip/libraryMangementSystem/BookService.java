package libraryMangementSystem;

import java.util.ArrayList;

public interface BookService {
	public Book addBook();
	public ArrayList<Book> getBook(ArrayList<Book> book);
	public Book getBookId(int id,ArrayList<Book> book);
	public String updateBook(int id,ArrayList<Book> book);
	public void deleteBook(int id,ArrayList<Book> book);

}
